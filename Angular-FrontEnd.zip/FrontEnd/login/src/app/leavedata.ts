export class Leavedata {
    constructor(public lid:number,
        public eid:number,
        public fdate:string,
        public tdate:string,
        public reason:string){}
}

