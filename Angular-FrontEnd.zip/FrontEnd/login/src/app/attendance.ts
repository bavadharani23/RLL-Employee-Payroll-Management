export class Attendance {
    constructor(public aid:number,
        public eid:number,
        public date:string,
        public status:string){}
}
