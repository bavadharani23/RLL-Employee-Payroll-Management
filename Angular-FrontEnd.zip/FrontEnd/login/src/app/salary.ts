export class Salary {
    constructor(public salaryid:number,
        public eid:number,
        public month:string,
        public salary:number){}
}
