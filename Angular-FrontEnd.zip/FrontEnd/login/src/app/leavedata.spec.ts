import { Leavedata } from './leavedata';

describe('Leavedata', () => {
  it('should create an instance', () => {
    expect(new Leavedata()).toBeTruthy();
  });
});
