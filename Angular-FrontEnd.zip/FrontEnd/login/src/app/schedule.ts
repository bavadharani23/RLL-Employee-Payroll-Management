export class Schedule {
    constructor(public sid:number,
        public eid:number,
        public date:string,
        public time:number,
        public task:string){}
}
